package a;

public class w1 {
    public static void main(String[] args) {
        boolean light_status = true;
        System.out.println("The current light status is:" + light_status);
    }
}
